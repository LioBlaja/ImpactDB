
DROP TABLE IF EXISTS Contract;
DROP TABLE IF EXISTS Course;
DROP TABLE IF EXISTS Auditorium;
DROP TABLE IF EXISTS Teacher;
DROP TABLE IF EXISTS Student;
DROP TABLE IF EXISTS Faculty;

CREATE TABLE Faculty(
fid CHAR (3) NOT NULL, --id faculty
name VARCHAR2 (40), --name faculty
adr VARCHAR2 (40), --faculty address
tel VARCHAR2 (12), --faculty main phone 
CONSTRAINT facult_pk PRIMARY KEY(fid)
);

CREATE TABLE Student(
sid CHAR(6) NOT NULL, --id student = student number
cnp CHAR (13), --cod numeric personal
name VARCHAR2(40) NOT NULL, --name of student
datab DATE, --date of birth
adr VARCHAR2 (40), --address student
year NUMBER(1) NOT NULL, --year of study (1,2,3,4, in particular cases 5,6)
grade average NUMBER (4,2), --the grade average of the last year completed
scholarship NUMBER (5,0), --current scholarship
fid CHAR (3) NOT NULL , --id faculty to which the student belongs
CONSTRAINT stud_pk PRIMARY KEY(sid),
CONSTRAINT facult_fk FOREIGN KEY (fid) REFERENCES faculty(fid) on delete cascade
);

CREATE TABLE Teacher(
pid CHAR (6) NOT NULL, --id teacher
cnp CHAR (13), --personal numeric code
name VARCHAR2 (40), --name of teacher
dateb DATE, --date of birth
fid CHAR (3) NOT NULL, --id faculty to which he belongs
grade varchar2(4) NOT NULL, -- teaching grade
CONSTRAINT prof_pk PRIMARY KEY(pid),
CONSTRAINT pfacult_fk FOREIGN KEY (fid) REFERENCES faculty(fid) on delete cascade,
CONSTRAINT pgradedidactiveexistent_ck CHECK(grade IN ('as', 'sl', 'conf', 'prof')) -- assistant, lecturer, head of works, lecturer, professor
);

CREATE TABLE Auditorium(
codea CHAR (4) NOT NULL, --room code
floor NUMBER (2), --floor
seats NUMBER (3), --maximum number of seats in the room
CONSTRAINT auditorium_pk PRIMARY KEY(codea)
);


CREATE TABLE Course(
    cid CHAR(5) NOT NULL, -- id course
    title VARCHAR2(32) NOT NULL, -- title course
    fid CHAR(3) NOT NULL, -- id faculty providing the course
    year NUMBER(1), -- year in which the course is held, if optional the year is null (e.g. pedagogy)
    semester NUMBER(2) NOT NULL, -- semester when the course is held
    pid CHAR(6), -- id full professor
    day VARCHAR2(8), -- day of the week in which the course takes place
    hour NUMBER(2), -- time when the course takes place
    codea CHAR(4), -- coding of the room where the course takes place
    CONSTRAINT crs_pk PRIMARY KEY(cid),
    CONSTRAINT cfacult_fk FOREIGN KEY (fid) REFERENCES Faculty(fid) ON DELETE CASCADE,
    CONSTRAINT crssala_fk FOREIGN KEY (codea) REFERENCES Auditorium(codea) ON DELETE CASCADE,
    CONSTRAINT crsprof_fk FOREIGN KEY (pid) REFERENCES Teacher(pid) ON DELETE CASCADE
);


CREATE TABLE Contract(
nrc NUMBER (5) NOT NULL,--contractnumber
sid CHAR (6) NOT NULL, --id student who signed the contract
cid CHAR(5) NOT NULL, --id course for which the contract was made
year NUMBER (4) NOT NULL, --the calendar year in which the contract was signed (e.g. 2023 for the school year 2023/2024)
semester NUMBER (1), --the semester when the course for which the contract was signed takes place
note NUMBER (4,2), --final note at the contracted rate in the year the contract was signed
CONSTRAINT contr_pk PRIMARY KEY(nrc),
CONSTRAINT constd_fk FOREIGN KEY (sid) REFERENCES Student(sid) on delete cascade,
CONSTRAINT concrs_fk FOREIGN KEY (cid) REFERENCES Course(cid) on delete cascade
);
